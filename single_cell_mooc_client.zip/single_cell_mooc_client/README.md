Helper functions to hide 'complexity' of submitting assignment answers.

Once changes are merged, to upload this to the internal BBP DevPi server, use
the following Jenkins plan:
https://bbpcode.epfl.ch/ci/view/platform/job/platform.mooc_single_cell_marking_client/
