voxcellview
===========

viewers for voxcell the brain building framework

Generation procedure
--------------------
use the cookiecutter template as described in the procedure in:
https://github.com/jupyter/widget-cookiecutter/


Installation
------------

To install use pip:

    $ pip install voxcellview
    $ jupyter nbextension install --py --user voxcellview
    $ jupyter nbextension enable --py --user voxcellview