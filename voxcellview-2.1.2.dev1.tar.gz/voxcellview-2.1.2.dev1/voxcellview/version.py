""" voxcellview version """
VERSION = '2.1.2.dev1'
